from django.contrib import admin

from news_api.app.models import NewsArticle

# Register your models here.
admin.site.register(NewsArticle)  

